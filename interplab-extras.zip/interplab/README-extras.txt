------------------------------------------------------------------
This folder contains two supplements to the interplab:

  InterpFull is an update of the Interp directory that was
   included in the main set of lab materials to include
   implementations for all of the eval() and exec() stubs.

  InterpFloat is a further extension of InterpFull that
   includes support for the double type (albeit using
   single precision floating point numbers) and the
   operations on them.

For example, the implementation of eval() in the Add class
in InterpFloat is as follows, using the type field that is
set during static analysis to determine whether the values
of the left and right subtrees should be combined using an
integer or floating point addition, as necessary.

    public int eval(int[] globals, int[] locals) {
        if (type.equals(Type.INT)) {
            return left.eval(globals, locals)
                 + right.eval(globals, locals);
        } else {
            return f2i(i2f(left.eval(globals, locals))
                     + i2f(right.eval(globals, locals)));
        }
    }

The f2i() and i2f() methods used here are defined as follows
in the Expr.java class, following the guidance in the original
lab materials:

    /** Interpret an integer value as a floating point number
     *  using the IEEE 754 floating-point "single format" bit
     *  layout.  (As captured by the intBitsToFloat() function
     *  in the standard Java APIs.)
     */
    public static float i2f(int i) {
        return Float.intBitsToFloat(i);
    }

    /** Interpret a floating point value as an integer
     *  using the IEEE 754 floating-point "single format" bit
     *  layout.  (As captured by the floatToRawIntBits()
     *  function in the standard Java APIs.)
     */
    public static int f2i(float f) {
        return Float.floatToRawIntBits(f);
    }

For further insight about the changes that were made in moving
from Interp to InterpFull, and then from InterpFull to InterpFloat,
you might like to use the following diff commands:

    diff -r -C 2 Interp InterpFull
    diff -r -C 2 InterpFull InterpFloat

------------------------------------------------------------------
